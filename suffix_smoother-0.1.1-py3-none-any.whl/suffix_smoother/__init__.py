"""
suffix_smoother — Recursive Suffix Smoothing Classifier
========================================================
Lightweight, domain-agnostic sequence classifier with graceful
out-of-vocabulary handling via progressive suffix backoff.

Quick start::

    from suffix_smoother import SuffixSmoother, SuffixConfig

    config = SuffixConfig(max_suffix_length=5, n_classes=2)
    smoother = SuffixSmoother(config)
    smoother.train([((101, 102, 103), 0), ((404, 500, 500), 1)])

    label, confidence = smoother.predict((101, 102, 103))
    # → (0, 0.87)

Changelog
---------
0.1.1
    Bug fixes: inference side-effect (predict no longer mutates tree),
    silent label validation (raises ValueError on bad labels),
    single-pass predict_distribution (~17x faster for large n_classes).
    New: uncertainty_reduction(), n_nodes, save()/load(), __version__.
0.1.0
    Initial release.
"""

from .smoother import SuffixSmoother, SuffixConfig, __version__

__all__ = ["SuffixSmoother", "SuffixConfig", "__version__"]
# predict_grouped is a method on SuffixSmoother — no separate export needed
