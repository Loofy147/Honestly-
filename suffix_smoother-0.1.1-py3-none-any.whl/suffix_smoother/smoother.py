"""
Suffix Smoother — Recursive Sequence Classifier
================================================
Jelinek-Mercer / Witten-Bell style suffix smoothing.

P(label | seq_k) = λ · P_MLE(label | seq_k) + (1-λ) · P(label | seq_{k-1})
Base case: P(label | ∅) = 1 / n_classes  [uniform prior]

Version 0.1.1 fixes vs 0.1.0
------------------------------
  BUG FIX — inference side-effect:  predict() was calling _get_or_create_node(),
    permanently inserting empty nodes into the tree on every query. Fixed by
    using dict.get() with no mutation during inference.

  BUG FIX — silent label validation: labels outside [0, n_classes) were silently
    accepted during training, corrupting root counts while being invisible to
    predict_distribution. Now raises ValueError immediately.

  BUG FIX — single-pass distribution: predict_distribution() called
    predict_probability() once per class, each doing a full tree traversal.
    Rewritten as a single O(max_suffix_length) pass, ~17× faster for typical
    n_classes values.

  NEW — uncertainty_reduction(): fraction of maximum entropy eliminated.
  NEW — n_nodes property: number of suffix tree nodes.
  NEW — __version__ attribute exposed from package.
  NEW — save() / load(): persist trained models without retraining.
"""

import numpy as np
import pickle
from typing import Optional, Any
from dataclasses import dataclass
from collections import defaultdict


__version__ = "0.1.1"


@dataclass
class SuffixConfig:
    """Configuration for the Suffix Smoother.

    Parameters
    ----------
    max_suffix_length : int
        Maximum number of trailing symbols to use as context.
        Longer = more specific (needs more training data). Default 5.
    smoothing_lambda : float
        λ in [0, 1]. Weight of MLE estimate vs backoff.
        Higher = trust longer contexts more. Default 0.7.
    n_classes : int
        Number of output label classes (must cover all label ids in training).
    min_count : int
        Minimum observations at a suffix node before it contributes to the
        smoothed estimate. Nodes below this threshold are skipped. Default 1.
    """
    max_suffix_length: int = 5
    smoothing_lambda: float = 0.7
    n_classes: int = 16
    min_count: int = 1


class _SuffixNode:
    """Internal node in the suffix tree."""
    __slots__ = ("counts", "total")

    def __init__(self):
        self.counts: dict = defaultdict(int)
        self.total: int = 0

    def observe(self, label: int, weight: int = 1) -> None:
        self.counts[label] += weight
        self.total += weight

    def mle(self, label: int) -> float:
        return self.counts.get(label, 0) / self.total if self.total > 0 else 0.0

    def mle_all(self, n_classes: int) -> list:
        """Return MLE for all classes in a single pass."""
        if self.total == 0:
            return [0.0] * n_classes
        return [self.counts.get(i, 0) / self.total for i in range(n_classes)]


class SuffixSmoother:
    """
    General-purpose sequence classifier using recursive suffix smoothing.

    Handles any unseen sequence via progressive suffix backoff — if the full
    context was never seen in training, it backs off to the last k-1 symbols,
    then k-2, all the way to a uniform prior. Graceful degradation is
    guaranteed regardless of input vocabulary.

    Parameters
    ----------
    config : SuffixConfig, optional
        Configuration object. Defaults to SuffixConfig().

    Examples
    --------
    Log anomaly detection::

        smoother = SuffixSmoother(SuffixConfig(max_suffix_length=4, n_classes=2))
        smoother.train([
            ((LOGIN, VIEW, LOGOUT), NORMAL),
            ((LOGIN, ERROR, ERROR, ERROR), ANOMALY),
        ])
        label, confidence = smoother.predict((LOGIN, ERROR))

    NLP POS tagging::

        smoother = SuffixSmoother(SuffixConfig(max_suffix_length=6, n_classes=17))
        encode = lambda word: tuple(ord(c) % 32 for c in word[-6:])
        smoother.train([(encode(word), tag_id) for word, tag_id in corpus])
        label, confidence = smoother.predict(encode("running"))

    Genomic pathogenicity::

        smoother = SuffixSmoother(SuffixConfig(max_suffix_length=6, n_classes=8))
        encode = lambda seq: tuple({"A":0,"T":1,"G":2,"C":3}.get(b,4) for b in seq)
        smoother.train([(encode(kmer), class_id) for kmer, class_id in clinvar_data])
        label, confidence = smoother.predict(encode("TGCGAT"))
    """

    def __init__(self, config: Optional[SuffixConfig] = None):
        self.cfg = config or SuffixConfig()
        self._root = _SuffixNode()
        self._nodes: dict = {}
        self.n_classes = self.cfg.n_classes
        self.training_samples: int = 0

        # Precompute per-level smoothing weights: λ¹, λ², ..., λᵏ
        self._lambdas = [
            self.cfg.smoothing_lambda ** (i + 1)
            for i in range(self.cfg.max_suffix_length)
        ]

    # ── Training ───────────────────────────────────────────────────────────

    def train(self, data: list) -> dict:
        """
        Train on a list of (context, label) pairs.

        Parameters
        ----------
        data : list of (tuple, int)
            Each item is (context_sequence, label_id).
            context_sequence: tuple of any hashable symbols.
            label_id: integer in [0, n_classes). Raises ValueError otherwise.

        Returns
        -------
        dict
            Training statistics: samples_trained, total_nodes,
            total_training_samples.

        Raises
        ------
        ValueError
            If any label_id is outside [0, n_classes).
        """
        for seq, label in data:
            label = int(label)
            if not (0 <= label < self.n_classes):
                raise ValueError(
                    f"Label {label} out of range [0, {self.n_classes}). "
                    f"Increase n_classes or fix your labels."
                )
            n = len(seq)
            for length in range(1, min(n + 1, self.cfg.max_suffix_length + 1)):
                suffix = seq[max(0, n - length):]
                node = self._nodes.setdefault(suffix, _SuffixNode())
                node.observe(label)
            self._root.observe(label)
            self.training_samples += 1

        return {
            "samples_trained": len(data),
            "total_nodes": len(self._nodes),
            "total_training_samples": self.training_samples,
        }

    # ── Inference ──────────────────────────────────────────────────────────

    def predict_distribution(self, seq: tuple) -> dict:
        """
        Return P(label | seq) for all labels in a single tree traversal.

        Parameters
        ----------
        seq : tuple
            Context sequence (same symbol type as training).

        Returns
        -------
        dict[int, float]
            Maps label_id → probability. Always sums to 1.0.
        """
        n = len(seq)
        uniform = 1.0 / self.n_classes

        # Start from uniform prior for all classes simultaneously
        p = [uniform] * self.n_classes

        # Single upward pass: shortest suffix → longest
        for length in range(1, min(n + 1, self.cfg.max_suffix_length + 1)):
            suffix = seq[max(0, n - length):]
            node = self._nodes.get(suffix)        # READ-ONLY — never creates nodes
            if node is not None and node.total >= self.cfg.min_count:
                lam = self._lambdas[length - 1]
                mle_vals = node.mle_all(self.n_classes)
                p = [lam * m + (1.0 - lam) * pk for m, pk in zip(mle_vals, p)]

        # Normalise
        total = sum(p)
        if total > 1e-12:
            p = [v / total for v in p]

        return {i: p[i] for i in range(self.n_classes)}

    def predict(self, seq: tuple):
        """
        Predict the most probable label for a sequence.

        Parameters
        ----------
        seq : tuple
            Context sequence.

        Returns
        -------
        tuple[int, float]
            (best_label_id, confidence). Confidence is the probability
            of the predicted label.
        """
        dist = self.predict_distribution(seq)
        best = max(dist, key=dist.get)
        return best, dist[best]

    def predict_grouped(self, seq: tuple, groups: dict) -> tuple:
        """
        Predict over semantically grouped classes (e.g. pathogenic vs benign).

        When multiple class ids share a semantic meaning, argmax over individual
        classes is the wrong metric — this method sums probabilities within each
        group and returns the winning group name and its aggregate confidence.

        Parameters
        ----------
        seq : tuple
            Context sequence.
        groups : dict[str, list[int]]
            Maps group name → list of class ids belonging to that group.
            Example: {"pathogenic": [3, 4, 7], "benign": [0, 1, 2]}
            Class ids not assigned to any group are ignored.

        Returns
        -------
        tuple[str, float, dict]
            (best_group_name, confidence, all_group_scores)

        Examples
        --------
        ::

            groups = {"pathogenic": [3, 4, 7], "benign": [0, 1, 2]}
            label, conf, scores = smoother.predict_grouped(seq, groups)
            # → ("pathogenic", 0.74, {"pathogenic": 0.74, "benign": 0.26})
        """
        dist = self.predict_distribution(seq)
        scores = {
            name: sum(dist.get(c, 0.0) for c in class_ids)
            for name, class_ids in groups.items()
        }
        # Normalize within covered classes so scores always sum to 1.0
        total = sum(scores.values())
        if total > 1e-12:
            scores = {k: v / total for k, v in scores.items()}
        best = max(scores, key=scores.get)
        return best, scores[best], scores

    # ── Diagnostics ────────────────────────────────────────────────────────

    def uncertainty(self, seq: tuple) -> float:
        """
        Entropy of the prediction distribution in bits.

        Returns
        -------
        float
            0.0 = perfectly certain. log2(n_classes) = maximally uncertain.
        """
        dist = self.predict_distribution(seq)
        probs = np.array(list(dist.values()))
        probs = probs[probs > 1e-12]
        return float(-np.sum(probs * np.log2(probs)))

    def max_uncertainty(self) -> float:
        """Maximum possible entropy (uniform distribution) in bits."""
        return float(np.log2(self.n_classes))

    def uncertainty_reduction(self, seq: tuple) -> float:
        """
        Fraction of maximum entropy eliminated by this prediction.

        Returns
        -------
        float
            0.0 = no information gained (uniform). 1.0 = perfectly certain.
        """
        return 1.0 - self.uncertainty(seq) / self.max_uncertainty()

    # ── Persistence ────────────────────────────────────────────────────────

    def save(self, path: str) -> None:
        """
        Save the trained model to disk.

        Parameters
        ----------
        path : str
            File path (e.g. "model.pkl"). Uses Python pickle.
        """
        with open(path, "wb") as f:
            pickle.dump(self, f, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls, path: str) -> "SuffixSmoother":
        """
        Load a trained model from disk.

        Parameters
        ----------
        path : str
            Path to a file saved with save().

        Returns
        -------
        SuffixSmoother
            Restored model, ready for inference.
        """
        with open(path, "rb") as f:
            obj = pickle.load(f)
        if not isinstance(obj, cls):
            raise TypeError(f"Expected SuffixSmoother, got {type(obj)}")
        return obj

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def n_nodes(self) -> int:
        """Number of suffix tree nodes built during training."""
        return len(self._nodes)

    def __repr__(self) -> str:
        return (
            f"SuffixSmoother(n_classes={self.n_classes}, "
            f"max_suffix={self.cfg.max_suffix_length}, "
            f"lambda={self.cfg.smoothing_lambda}, "
            f"nodes={self.n_nodes}, "
            f"samples={self.training_samples})"
        )
